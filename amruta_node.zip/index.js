const express = require('express');
const async = require('async');
var crud = require("./crud")
var bodyParser = require('body-parser')
var validator = require('validator');
var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'sneha'
});


const app = express();
app.set("view engine","ejs");
// app.use(express.static('public'));
app.use("/public", express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.get('/', function (req, res) {
	
	//console.log("here")
	async.parallel({
	    br: function(callback) {
	    	connection.query("select * from brand",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	        // console.log(1)
	    },
	    cat: function(callback) {
	       connection.query("select * from category",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	    },
	    pro: function(callback) {
	       connection.query("select * from product",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	    }
	}, function(err, results) {
	    // console.log(results)
	    /*
		[
			0=>{
				br:[]
			}
		]
	    */
	    if(!err){
		  	res.render('index',results)

	    }
	});	
})

app.get('/login', function (req, res) {
  res.render('login')
})

app.post("/register-action",function(req,res){
	// console.log(req.body)
	// res.send("test")
	if(!validator.matches(req.body.login_name,/^[a-zA-Z]([a-zA-Z ]+)?[a-zA-Z]$/)){
		msg = "Invalid name";
	}
	else if(!validator.isMobilePhone(req.body.login_mobile,'en-IN')){
		msg = "Invalid Mobile";
	}
	else if(!validator.isEmail(req.body.login_email)){
		msg = "Invalid Emailid";
	}
	else if(validator.isEmpty(req.body.login_password) || !validator.isAlphanumeric(req.body.login_password) || !validator.isLength(req.body.login_password,{min:4, max: 12})){
		msg = "Invalid password";
	}
	else if(!validator.equals(req.body.login_password, req.body.login_cpassword)){
		msg = "Invalid Confirm Password";
	}
	else{
		delete req.body.login_cpassword;
		crud.insert("userinfo",req.body,function(result,error){
			if(!error){
				msg = "User Added";
			}
			else{
				console.log(error);
				return false;
			}
		})
		
	}
	res.send(msg);
})

app.get("/filter-category/:id",function(req,res){
	console.log(req.params)
	id = req.params.id;
	str =`select * from product where procatid='${id}'`
	connection.query(str,function(err,result){
		if(!err){
			 console.log(result);
			res.render("categoryWisePage",{record:result});
		}
	})
}) 

app.post("/filter-brand",function(req,res){
	// console.log(req.body)
	id = req.body.id;
	str =`select * from product where probrid='${id}'`
	connection.query(str,function(err,result){
		if(!err){
			// console.log(result);
			res.send(result);
		}
	})
})



app.listen(3000)