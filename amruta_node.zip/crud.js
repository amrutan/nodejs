var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'sneha'
});

var select = function(){}
var insert = function(table,rec,callback){
	// callback()
	// console.log(rec)
	// console.log(table)
	var col = "";
	var value = "";
	for(key in rec){
		col+=key+",";
		value+="'"+rec[key]+"',";
	}
	// console.log(value);
	// console.log(col);
	col = col.substring(0,col.length-1);
	value = value.substring(0,value.length-1);
	str = `insert into ${table} (${col}) values (${value}) `;
	// console.log(str)
	connection.query(str,function(error,results){
		if(!error){
			callback(results,null);
		}	
		else{
			callback(null,error);
		}	
	})

}
var update = function(){}
var del = function(){}

module.exports = {
	select:select,
	insert:insert,
	update:update,
	delete:del,
}