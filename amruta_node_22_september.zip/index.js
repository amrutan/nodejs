const express = require('express');
const async = require('async');
var crud = require("./crud")
var bodyParser = require('body-parser')
var validator = require('validator');
var mysql      = require('mysql');
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
var jwt = require('jsonwebtoken');
var cookieParser = require('cookie-parser')
const saltRounds = 10;
const exp = 120 * Date.now();
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'sneha'
});
var multer  = require('multer');
var upload = multer({ dest: 'uploads/' })
var payUMoney = require('payumoney_nodejs')
const MERCHANT_KEY = '6PqKSK15'
const MERCHANT_SALT = 'sAOVPuJG2X'
//const PAYUMONEY_AUTHORIZATION_HEADER = '5553983'
payUMoney.setProdKeys(MERCHANT_KEY, MERCHANT_SALT);
payUMoney.isProdMode(true); 
//payumoney.setSandboxKeys(MERCHANT_KEY, MERCHANT_SALT, PAYUMONEY_AUTHORIZATION_HEADER);

const app = express();
app.set("view engine","ejs");
//app.use(express.static('public'));
app.use("/public", express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(cookieParser())

app.use(function(req,res,next){
	//console.log(req.cookies);
    arr1 = ["/login"];
    arr2 = ["/password"];
    cartData = req.cookies.cartPro;
    if (cartData === undefined) {
    	cartshow = 0;
    } else {
    	cartDataArray = cartData.split(",");
    	cartshow = cartDataArray.length;
    }
    app.locals.cartCount = cartshow;
    //console.log("app.locals.cartCount",app.locals.cartCount)
    ////console.log(app.locals.cartCount);
    if (arr1.indexOf(req.url) > -1) {
    	//console.log(req.cookies.userToken);
    	//return;
        if (req.cookies.userToken === undefined) {
        	next();
        } else {
        	res.redirect("/");
        }
         // next();
    }
    else if (arr2.indexOf(req.url) > -1) {
        if(req.cookies.userToken === undefined) {
        	res.redirect("/");
        } else {
        	// next();
        	var decoded = jwt.verify(req.cookies.userToken, "hello");
        	if (decoded.exp <= exp) {
        		res.redirect("/");
        	}
        }
        next();

    } else {
        next();
    }
})

app.get('/', function (req, res) {
	
	////console.log("here")
	async.parallel({
	    br: function(callback) {
	    	connection.query("select * from brand",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	        //// console.log(1)
	    },
	    cat: function(callback) {
	       connection.query("select * from category",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	    },
	    pro: function(callback) {
	       connection.query("select * from product",function(err,result){
	    		if(!err){
		        	callback(null, result);
	    		}
	    		else{
		        	callback(err, null);
	    		}
	    	})
	    }
	}, function(err, results) {
	    //// console.log(results)
	    /*
		[
			0=>{
				br:[]
			}
		]
	    */
	    if(!err){
		  	res.render('index',results)

	    }
	});	
})

app.get('/login', function (req, res) {
  res.render('login')
})

app.get('/password', function (req, res) {
  res.render('password')
})

app.post("/register-action",function(req,res){
	//// console.log(req.body)
	// res.send("test")
	let msg = "";
	if(!validator.matches(req.body.login_name,/^[a-zA-Z]([a-zA-Z ]+)?[a-zA-Z]$/)){
		msg = "Invalid name";
	}
	else if(!validator.isMobilePhone(req.body.login_mobile,'en-IN')){
		msg = "Invalid Mobile";
	}
	else if(!validator.isEmail(req.body.login_email)){
		msg = "Invalid Emailid";
	}
	else if(validator.isEmpty(req.body.login_password) || !validator.isAlphanumeric(req.body.login_password) || !validator.isLength(req.body.login_password,{min:4, max: 12})){
		msg = "Invalid password";
	}
	else if(!validator.equals(req.body.login_password, req.body.login_cpassword)){
		msg = "Invalid Confirm Password";
	}
	else{
		delete req.body.login_cpassword;
		//let passSalt;
         bcrypt.hash(req.body.login_password, saltRounds, function(err, hash) {
         	if (err) {
         		//console.log(err);
         	} else {
                req.body.login_password = hash;
                //console.log(req.body);
                crud.insert("userinfo",req.body,function(result,error){
					if(!error){
						msg = "User Added";
						/*********MAILER***********/
		  				async function main(){

						  // Generate test SMTP service account from ethereal.email
						  // Only needed if you don't have a real mail account for testing
						  let testAccount = await nodemailer.createTestAccount();

						  // create reusable transporter object using the default SMTP transport
						  let transporter = nodemailer.createTransport({
						    host: "mail.php-training.in",
						    port: 587,
						    secure: false, // true for 465, false for other ports
						    auth: {
						      user: "vishal@php-training.in", // generated ethereal user
						      pass: "Vishal@123" // generated ethereal password
						    },
						    tls: { rejectUnauthorized: false }
						  });

						  // send mail with defined transport object
						  let info = await transporter.sendMail({
						    from: '<vishal@php-training.in>', // sender address
						    to: req.body.login_email, // list of receivers
						    subject: "Hello ✔", // Subject line
						    text: "Hello world?", // plain text body
						    html: "<b>Hello world?</b>" // html body
						  });

						  //console.log("Message sent: %s", info.messageId);
						  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

						  // Preview only available when sending through an Ethereal account
						  //console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
						  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
						}

						main().catch(console.error);
		  				/*********MAILER***********/
					}
					else{
						//console.log(error);
						return false;
					}
			    });
            }
         });
	}
	res.send(msg);
})

app.get("/filter-category/:id",function(req,res){
	//console.log(req.params)
	id = req.params.id;
	str =`select * from product where procatid='${id}'`
	connection.query(str,function(err,result){
		if(!err){
			 //console.log(result);
			res.render("categoryWisePage",{record:result});
		}
	})
}) 

app.post("/filter-brand",function(req,res){
	//// console.log(req.body)
	id = req.body.id;
	str =`select * from product where probrid='${id}'`
	connection.query(str,function(err,result){
		if(!err){
			//// console.log(result);
			res.send(result);
		}
	})
})

app.post("/login-action",function(req,res){
	 //// console.log(req.body)
	// res.send("test")
	let msg = "";
	if(!validator.isEmail(req.body.login_email) || validator.isEmpty(req.body.login_email)){
		msg = "Invalid Email";
		res.send(msg);
	}
	else if(validator.isEmpty(req.body.login_password) || !validator.isAlphanumeric(req.body.login_password) || !validator.isLength(req.body.login_password,{min:4,max:18})){
		msg = "Invalid Password"
		res.send(msg);
	}
	else{
		crud.select("*","userinfo",`login_email='${req.body.login_email}'`, function(result, error){
			if (!error) {
				if(result.length>0){
					dbpass = result[0]['login_password'];
					bcrypt.compare(req.body.login_password, dbpass, function(err, response_hash) {
					    if(response_hash){
					    	msg ='valid';
					    	//// console.log("valid");
					    	//*******************//
					    	var token = jwt.sign({
					    		email: req.body.login_email
					    	}, 'hello', {expiresIn: 60*60});
					    	res.cookie("userToken", token, {expire: exp});
					    	app.locals.userEmail = req.body.login_email;
					    	res.send(msg);
					    }
					});
				}
				else{
					msg = "Invalid Email";
					res.send(msg);
				}
			} else {
				//console.log(error);
			}
		})
	}
	////console.log(msg);
	
})

app.get('/category', function (req, res) {
  res.render('category')
})

app.post("/category-action",function(req,res){
	//console.log(req);
	crud.insert("category",req.body,function(result,error){
		if (!error) {
			res.send("Category Added");
		} else {
			//console.log(error);
		}
	});
})

app.get('/product', function (req, res) {
  async.parallel({
    cat: function(callback) {
    	crud.select("*", 'category', 1, function(error, result){
    		if (!error) {
                callback(null, result);
    		}
    	})
    },
    br: function(callback) {
        crud.select("*", 'brand', 1, function(error, result){
    		if (!error) {
                callback(null, result);
    		}
    	})
    }
   }, function(err, results) {
      // results now equals to: results.one: 'abc\n', results.two: 'xyz\n'
      //console.log(results)
      res.render('product', results);
  });
  
})

app.post("/product-action",upload.single('proimg'), function(req,res){
	//console.log(req.file);
	req.body.proimg = req.file.filename;
	crud.insert("product",req.body,function(result,error){
		if (!error) {
			res.send("Product Added");
		} else {
			//console.log(error);
		}
	});
})

app.post("/cart-action",function(req,res){
	//console.log("request body", req.body);
	productid = req.body.id;
	//res.cookie('cartpro', productid);
	str="";
	//console.log("req.cookies.cartPro", req.cookies.cartPro);
	if(req.cookies.cartPro === undefined) {
		//console.log("undefined initially");
        res.cookie("cartPro", productid, {expire:exp*1000});
        str=`Product Added#${productid}`;
        res.send(str);
	} else {
		cartData = req.cookies.cartPro;

		cartValues = cartData.split(",");
		if (cartValues.indexOf(productid) == -1) {
			cartValues.push(productid);
			res.cookie("cartPro", cartValues.join(","), {expire:exp*1000});
			str=`Product Updated#${productid}`;
            res.send(str);
		} else {
			str=`Product already exists in cart#${productid}`;
            res.send(str);
		}
	}
})

app.post('/profile', upload.single('proimg'), function (req, res, next) {
  // req.file is the `avatar` file
  // req.body will hold the text fields, if there were any
})

app.get('/checkout', function (req, res) {
  res.render('checkout')
})

app.get('/cart', function (req, res) {
  //console.log("req.cookies.cartPro", req.cookies.cartPro);
  prodList = req.cookies.cartPro.substring(0, req.cookies.cartPro.length - 1);
  str =`select * from product where id IN (${prodList})`
  //console.log(str);
	connection.query(str,function(err,result){
		if(!err){
			console.log(result);
			res.render("cart",{record:result});
		}
	})
  res.render('cart')
})

app.get('/checkout-action', function (req, res, next) {
  // req.file is the `avatar` file
  // req.body will hold the text fields, if there were any
  var requestBody = {
      "firstname" : "amruta",
      "lastname" : "nevrekar",
      "email" : "amruta.nevrekar@gmail.com",
      "phone" : 9766731354,
      "amount" : 1,
      "productinfo" : "fdfdfd",
      "txnid" : 1234, //generate unqiue transaction Id at client/server side
      "surl" : "http://localhost:3000/payment/success",
      "furl" : "http://localhost:3000/payment/failure"
    };
  
  payUMoney.pay(requestBody, function(error, response) {
  	  console.log("Error", error);
  	  console.log("Response", response);
      if (error) {
        // Some error console.log(response);
      } else {
        // You will get a link in response to redirect to payUMoney
       //callback(null, { 'payulink' : response });
       var payulink = response;
       res.redirect(payulink);
      }
    });
})

app.post("/success", function(req,res){
	console.log(req.body);
	
})

app.post("/failure", function(req,res){
	console.log(req.body);
	
})
app.listen(3000)