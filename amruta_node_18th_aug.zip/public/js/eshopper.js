$(function(){
	$("#reg_form").submit(function(obj){
		obj.preventDefault();
		rec = $("#reg_form").serialize();
		$.post("/register-action",rec,function(res){
			$(".reg_result").html(res)
		})
	})
	//login form
	$("#login-form").submit(function(obj){
		//console.log(obj)
		obj.preventDefault();
		rec = $("#login-form").serialize();
		//console.log(rec);
		$.post("/login-action",rec,function(res){
			$(".login_result").html(res);
			window.location.href="/";

		})
	})
	///////////
	$(".brdata").click(function(obj){
		obj.preventDefault();
		rec = $(this).attr("for");
		$.post("/filter-brand",{id:rec},function(res){
			str = "";
			res.forEach( function(element, index) {
				str += `
				<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="/public/images/home/product1.jpg" alt="" />
											<h2>${element.proprice}</h2>
											<p>${element.proname}</p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
										<div class="product-overlay">
											<div class="overlay-content">
												<h2>${element.proprice}</h2>
											<p>${element.proname}</p>
												<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											</div>
										</div>
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul>
								</div>
							</div>
						</div>
				`;
				// console.log(str);
				$(".features_items").html(str);
			});
		})
	})
	/////////
})